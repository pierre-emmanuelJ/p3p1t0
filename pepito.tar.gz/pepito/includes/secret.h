
#ifndef   SECRET_H
# define    SECRET_H

int handlerMakeSecretRecipes(void *packetPtr, size_t packetSize);

#endif     /* !SECRET_H */
