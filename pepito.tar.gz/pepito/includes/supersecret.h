#ifndef   SUPERSECRET_H
# define    SUPERSECRET_H

int handlerMakeSuperSecretRecipes(void *packetPtr, size_t packetSize);

#endif     /* !SECRET_H */
